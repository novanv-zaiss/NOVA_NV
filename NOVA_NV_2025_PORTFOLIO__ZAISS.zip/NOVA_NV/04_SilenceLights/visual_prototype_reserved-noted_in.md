> *Note: A prototype or sketch of the interface will be added in a future design iteration.*
