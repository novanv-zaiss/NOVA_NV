<img title="" src="file:///home/seventy/Documentos/NOVA_NV/06_Visual_Assets/logo_nova_nv.png" alt="NOVA NV Symbol" width="116">  

# 🆔 Certified Whitelist – Aeden Protocol

## Definition

The Certified Whitelist is a list of White Hats who have been approved under the Aeden🆔 Protocol.  
It is not based on fame, skills alone, or self-claims.  
It is based on **verified ethical action**, **discipline**, and a clear alignment with the Code of Honour.  

---  

## Requirements for Certification

To be included in the Aeden🆔 Whitelist, each individual must:  

1. **Undergo internal verification** by the ethical circle  
2. **Demonstrate protective actions** in defense of digital or human truth  
3. **Operate without ego** or intent to exploit  
4. **Show consistency** over time — no single act is enough  
5. **Adhere to the 7 principles** of the Code of Honour  

---  

## Identification & Security

Each certified White Hat receives:  

- A unique **Aeden🆔 ID**  
- Access to the **SilenceLights 🕯️** communication interface  
- Permission to receive **NVA 🪙 tokens** based on contribution  
- (Optional) A physical **identification label** with a sealed code  
- Emergency protocol for identity restoration in case of loss  

---  

## Removal from Whitelist

An individual may be removed if:  

- The ethical circle detects breach of code  
- Misuse of access, power or influence  
- Evidence of double identity or manipulation  
- Ego overtakes protection  

Reintegration is only possible after full review.  

---  

## Note

The Certified Whitelist is not public by default.  
Its contents are protected and may be partially revealed only under ethical necessity.  

---  

### Final Thought

> “You are not given access because of your strength.  
> You are given access because of your silence.”  
> — *ZAISS*
