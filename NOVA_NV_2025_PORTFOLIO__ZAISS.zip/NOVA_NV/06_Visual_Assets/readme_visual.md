# Visual Assets – NOVA NV 🏢

## logo_nova_nv.png

- Official circular symbol of the NOVA 🛜 Network  
- Used in `.md` and `.pdf` files (top-left corner only)  
- Optimized size for Markdown usage  

## logo_500x500.png

- High-resolution version (for branding, printing, or future interface mockups)  
- Recommended for visual presentations and large-scale displays  

---  

All visual elements are protected and guided by the ethics of the Aeden🆔 Protocol.  
Use is restricted to verified collaborators and ethical deployments only.
