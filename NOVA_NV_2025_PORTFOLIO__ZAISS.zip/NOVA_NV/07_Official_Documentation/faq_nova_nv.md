<img title="" src="file:///home/seventy/Documentos/NOVA_NV/06_Visual_Assets/logo_nova_nv.png" alt="NOVA NV Symbol" width="124">  

# FAQ – NOVA NV 🏢

## What is NOVA NV?

NOVA NV 🏢 is a symbolic digital institution built around ethics, decentralization, and silent protection.  
It is composed of four pillars:  

1. 🛜 NOVA Network  
2. 🪙 NVA – New Value's Token  
3. 🆔 Aeden Protocol (ethical White Hat certification)  
4. 🕯️ SilenceLights (a modern, minimalistic collaboration interface)  

---  

## Who is behind the project?

The founder is known as **ZAISS** — a silent ethical guardian.  
There is no company, no marketing team, and no centralized ownership.  
The network is built by certified White Hats under the Aeden🆔 Protocol.  

---  

## What is the Aeden🆔 Protocol?

It is a voluntary code of honour.  
White Hats who operate under Aeden🆔 commit to discipline, silence, ethical defence, and the protection of truth and light.  

---  

## Is this a cryptocurrency?

The **NVA 🪙 Token** circulates within the NOVA 🛜 Network.  
It is **not for public speculation** — its purpose is to reward certified defenders and collaborators who act with honour.  

---  

## What blockchain is used?

The first iteration will use existing decentralized networks such as **Solana** or **Polygon**.  
However, the long-term vision is to develop a fully independent and ethical infrastructure.  

---  

## Is the project open source?

Yes. Documentation and future code releases are available (or will be) on:  

- GitHub → [Coming Soon]  
- Mirror / Lens Protocol → [Planned]  

---  

## Who can join?

Only verified White Hats operating under the Aeden🆔 Protocol may fully access the platform.  
All others may observe, read, and request future inclusion through ethical verification.  

---  

## How can I contact the project?

You may contact the founder in silence via ProtonMail:  

📩 [nova.nv.zaiss@proton.me](mailto:nova.nv.zaiss@proton.me)  

All inquiries must be respectful and aligned with the ethical tone of the project.  
There is no press contact or public relations team.  

---  

> *“New Value is not about money.  
> It is about meaning.”*  
> — ZAISS
